$(document).ready(function(){
$('#1').click(function(){
    $('#1').css('visibility', 'hidden');
})
$('#2').click(function(){
    $('#2').css('visibility', 'hidden');
})
$('#3').click(function(){
    $('#3').css('visibility', 'hidden');
})
$('#4').click(function(){
    $('#4').css('visibility', 'hidden');
})
$('#5').click(function(){
    $('#5').css('visibility', 'hidden');
})
$('#6').click(function(){
    $('#6').css('visibility', 'hidden');
})
$('#7').click(function(){
    $('#7').css('visibility', 'hidden');
})
$('#8').click(function(){
    $('#8').css('visibility', 'hidden');
})


$('button').click(function(){
    $('img').css('visibility', 'visible');
})
})

// with (this) --works also

// $('img').click(function(){
//     $(this).css('visibility', 'hidden');
// })


// })